/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modelo;

import java.util.List;
import java.util.Stack;

/**
 *
 */
public class Examen implements Cloneable{
    
    private int id;
    private int numeroPreguntas;
    private String nombre;
    private List<Pregunta> preguntas;
    private List<Tema> temas;

    public Examen() {
        preguntas = new Stack<>();
        temas = new Stack<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Pregunta> getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(List<Pregunta> preguntas) {
        this.preguntas = preguntas;
    }

    public List<Tema> getTemas() {
        return temas;
    }

    public void setTemas(List<Tema> temas) {
        this.temas = temas;
    }

    public int getNumeroPreguntas() {
        return numeroPreguntas;
    }

    public void setNumeroPreguntas(int numeroPreguntas) {
        this.numeroPreguntas = numeroPreguntas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException {
        Object object = null;
        try{
            object = super.clone();
        }catch(CloneNotSupportedException e){
            e.printStackTrace();
        }
        return object;
    }
    
    public void agregarPregunta(Pregunta p){
        if (preguntas == null){
            preguntas = new Stack<>();
        }
        preguntas.add(p);
    }
    
    public void agregarTema(Tema t){
        if (temas == null){
            temas = new Stack<>();
        }
        temas.add(t);
    }

    @Override
    public String toString() {
        return getId() + " " + getNombre()+ " " + getNumeroPreguntas();
    }
    
    
    
}
