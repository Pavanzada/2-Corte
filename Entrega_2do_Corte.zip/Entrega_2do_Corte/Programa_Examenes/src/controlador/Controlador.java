/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controlador;

import modelo.Examen;
import modelo.Materia;
import modelo.Pregunta;
import modelo.Tema;

/**
 *
 */
public class Controlador {
    
    
    //BuilderI
    private ExamenBuilder builder;
    //BuilderF
    
    private SQLUtil utilSQL;
    
    //SinglentonI
    private static Controlador instancia = new Controlador();

    public static Controlador getInstance(){
        return instancia;
    }
    //SinglentonF
    
    public Controlador() {
        //PrototypeI
        CachePR.cargarCache();
        //PrototypeF
        builder =  new ExamenBuilder();
        utilSQL = new SQLUtil();
    }

    public Tema crearTema(String nombre){
        return builder.generaTema(nombre);
    }
    
    public Materia crearMateria(String nombre){
        return builder.generaMateria(nombre);
    }
    
    public Examen crearExamen(String nombre){
        return builder.generarExamen(nombre);
    }
    
    public ExamenBuilder getBuilder(){
        return builder;
    }
    
    public void agregarTema(Tema t){
        CachePR.agregarTema(t);
        utilSQL.agregarTema(t);
    }
    
    public void actualizarTema(Tema tema){
        utilSQL.actualizarTema(tema);
    }
    
    public void eliminarTema(Tema tema){
        utilSQL.eliminarTema(tema);
    }
    
    public void agregarMateria(Materia m){
        CachePR.agregarMateria(m);
        utilSQL.agregarMateria(m);
    }
    
    public void actualizarMateria(Materia m){
        utilSQL.actualizarMateria(m);
    }
    
    public void eliminarMateria(Materia m){
        utilSQL.eliminarMateria(m);
    }
    
    public void agregarPregunta(Pregunta p){
        CachePR.agregarPregunta(p);
        utilSQL.agregarPregunta(p);
    }
    
    public void actualizarPregunta(Pregunta p){
        utilSQL.actualizarPregunta(p);
    }
    
    public void eliminarPregunta(Pregunta p){
        utilSQL.eliminarPregunta(p);
    }
    
    public void agregarExamen(Examen e){
        CachePR.agregarExamen(e);
        utilSQL.agregarExamen(e);
    }
    
    public void actualizarExamen(Examen e){
        utilSQL.actualizarExamen(e);
    }
    
    public void eliminarExamen(Examen e){
        utilSQL.eliminarExamen(e);
    }
    
}
