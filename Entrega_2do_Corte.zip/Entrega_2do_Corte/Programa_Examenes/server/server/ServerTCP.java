/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import controlador.SQLUtil;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;


public class ServerTCP implements Runnable {

    private ServerSocket server;
    private int port = 4444;
    private boolean arriba = false;
    protected Thread runningThread = null;
    private SQLUtil utilSql;

    public ServerTCP() {
        utilSql = new SQLUtil();
    }

    public ServerTCP(int port) {
        this();
        this.port = port;
    }

    public void iniciarServidor() {
        try {
            server = new ServerSocket(port);
            System.out.println("Servidor Java Activo! \n");
            System.out.println("" + server + "\n");
            arriba = true;
            utilSql.agregarAuditoria(new String[]{"servidor", "localhost"});
        } catch (IOException e) {
            System.err.println("No se pudo iniciar el servidor puerto " + port + " ocupado ");
            e.printStackTrace();
        }
    }

    public synchronized void apagarServidor() {
        this.arriba = false;
        if (this.server != null) {
            if (!this.server.isClosed()) {
                try {
                    this.server.close();
                    System.out.println("Servidor Java Apagado! \n");
                } catch (IOException e) {
                    System.err.println("No se pudo apagar el servidor ");
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void run() {
        synchronized (this) {
            this.runningThread = Thread.currentThread();
        }
        iniciarServidor();
        while (estaArriba()) {
            Socket cliente = null;
            try {
                cliente = this.server.accept();
            } catch (IOException e) {
                if (!estaArriba()) {
                    System.err.println("El servidor se encuentra apagado");
                    return;
                }
                e.printStackTrace();
            }
            if (cliente != null) {
                try {
                    new Thread(new ClienteConectado(cliente, utilSql)).start();
                } catch (IOException e) {
                    System.err.println("Ocurrio un error al momento de leer el cliente");
                    e.printStackTrace();
                }
            }
        }
        System.out.println("El servidor se encuentra apagado");
    }

    private synchronized boolean estaArriba() {
        return this.arriba;
    }
    
    public static void main(String[] args) throws IOException {
        ServerTCP serverTCP = new ServerTCP();
        new Thread(serverTCP).start();
        while (true) {
            try {
                Thread.sleep(2 * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}

class ClienteConectado implements Runnable {

    private Socket cliente;
    private BufferedReader reader;
    private PrintWriter writer;
    private String clientRequest;
    private String ip;
    private SQLUtil con;

    public ClienteConectado(Socket cliente, SQLUtil con) throws IOException {
        this.cliente = cliente;
        reader = new BufferedReader(new InputStreamReader(this.cliente.getInputStream()));
        writer = new PrintWriter(new OutputStreamWriter(this.cliente.getOutputStream()), true);
        writer.println("Bienvenido al Servidor: " + new Date() + "/n");
        ip = cliente.getLocalAddress().getHostAddress();
        this.con = con;
        con.agregarAuditoria(new String[]{"conexion", ip});
    }

    @Override
    public void run() {
        while (true) {
            try {
                clientRequest = reader.readLine();

                System.out.println("Recibido de : " + clientRequest);
                if (clientRequest !=  null)
                con.agregarAuditoria(new String[]{clientRequest, ip});

                if (clientRequest.startsWith("S")) {
                    writer.println("Adios :" + InetAddress.getLocalHost());
                    cliente.close();
                    break;
                }
            } catch (Throwable e) {
                System.out.println("Excepción en el servidor " + e);
                writer.println("Adios :");
                try {
                    cliente.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                break;
            }
        }
    }

    public String getClientRequest() {
        return clientRequest;
    }

    public void setClientRequest(String clientRequest) {
        this.clientRequest = clientRequest;
    }

}
